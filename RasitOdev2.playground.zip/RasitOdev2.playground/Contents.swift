import UIKit
// Fahreddin Raşit KILIÇ - INVIO IOS DEVELOPER BOOTCAMP ÖDEV2
class Odev {
    func soru1(derece:Double) -> Double {
        return derece * 1.8 + 32
    }
    func soru2(ukenar:Int, kkenar:Int) -> Int {
        return 2 * (ukenar + kkenar)
    }
    func soru3(faktorparam:Int) -> Int {
        var sonuc = 1
        var faktordeger = faktorparam
        if faktordeger == 0 {
            return 1
        } else {
            while faktordeger != 1 {
                sonuc = faktordeger * sonuc
                faktordeger = faktordeger - 1
            }
        }
        return sonuc
    }
    func soru4(kelime:String, harf:Character) -> Int {
        var count = 0
        for x in kelime {
            if x == harf {
                count = count + 1
            }
        }
        return count
    }
    func soru5(ksayisi:Int) -> Int {
        return (ksayisi-2) * 180
    }
    func soru6(gunsayisi:Int) -> Int {
        var maas = 0
        let mesaiSaati = gunsayisi * 8
        if(mesaiSaati > 160) {
            maas = (mesaiSaati - 160) * 20 + 160 * 10
        } else {
            maas = mesaiSaati * 10
        }
        return maas
    }
    func soru7(kotamiktar:Int) -> Int{
        if(kotamiktar <= 50) {
            return 100
        } else {
            return 100 + (kotamiktar - 50) * 4
        }
    }
}

let o = Odev()

//DEĞİŞKENLER
//SORU1
let celcius = 24.0
//SORU2
let ukenar = 21
let kkenar = 5
//SORU3
let faktor = 9
//SORU4
let kelime = "invio ios developer bootcamp"
let karakter:Character = "i"
//SORU5
let kenarsayisi = 6
//SORU6
let gunsayisi = 24
//SORU7
let kotamiktar = 72

let fahrenheit = o.soru1(derece: celcius)
print("SORU1 ||| \(celcius) Celsius = \(fahrenheit) Fahrenheit ")

let cevre = o.soru2(ukenar: ukenar, kkenar: kkenar)
print("SORU2 ||| Uzun kenarı \(ukenar) Kısa Kenarı \(kkenar) olan dikdörtgenin çevresi = \(cevre) dir ")

let faktoriyel = o.soru3(faktorparam: faktor)
print("SORU3 ||| \(faktor) sayısının faktöriyeli = \(faktoriyel) dir ")

let adet = o.soru4(kelime: kelime, harf: karakter)
print("SORU4 ||| \(kelime) ifadesinin içinde \(adet) adet \(karakter) harfi vardır ")

let icAciToplam = o.soru5(ksayisi: kenarsayisi)
print("SORU5 ||| kenar sayısı \(kenarsayisi) olan çokgenin iç açılar toplamı \(icAciToplam) dir ")

let maas = o.soru6(gunsayisi: gunsayisi)
print("SORU6 ||| \(gunsayisi) gün çalışan birinin maaşı \(maas) dır ")

let fatura = o.soru7(kotamiktar: kotamiktar)
print("SORU7 ||| \(kotamiktar) gb internet harcayan birisinin fatura ücreti \(fatura) dir ")

